package com.javainterviewpoint.soumyadeep;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.javainterviewpoint.soumyadeep"})
public class SbElasticSearchJavainterviewpointApplication implements CommandLineRunner{

  @Resource
  private StudentRepository studentRepository;

  public static void main(String[] args) {
    
    SpringApplication.run(SbElasticSearchJavainterviewpointApplication.class,
        args);
  }
  @Override
  public void run(String... args) throws Exception {
    Student s1 = new Student(1L, "soumyadeep1", "s1");
    Student s2 = new Student(2L, "soumyadeep2", "s2");
    Student s3 = new Student(3L, "soumyadeep3", "s3");
    Student s4 = new Student(4L, "soumyadeep4", "s4");
    Student s5 = new Student(5L, "soumyadeep5", "s5");
    Student s6 = new Student(6L, "soumyadeep6", "s6");
    Student s7 = new Student(7L, "soumyadeep7", "s7");
    Student s8 = new Student(8L, "soumyadeep8", "s8");

    studentRepository.save(s1);
    studentRepository.save(s2);
    studentRepository.save(s3);
    studentRepository.save(s4);
    studentRepository.save(s5);
    studentRepository.save(s6);
    studentRepository.save(s7);
    studentRepository.save(s8);

    System.out.println("<<<<retrieve all students>>>>");
    for (Student s : studentRepository.findAll()) {
      System.out.println(s);
    }

    System.out.println("<<<<retrieve by age 4>>>>");
    System.out.println(studentRepository.findByAge("4"));

    System.out.println("<<<<retrieve by name soumyadeep1>>>>");
    System.out.println(studentRepository.findByName("soumyadeep1"));

    System.out.println("<<<<retrieve by name soumyadeep1>>>>");
    System.out.println(studentRepository.findByName("soumyadeep1"));

    System.out.println("<<<<retrieve by any one>>>>");
    //System.out.println(studentRepository.findById(6L));
    
  }
}
